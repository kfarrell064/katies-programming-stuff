package DanceEggS;
import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout
public class DanceEggS extends JPanel
{
    Color c = new Color((int)(Math.random() * 255), (int)(Math.random() * 255), (int)(Math.random() * 255));
    int x = 180, y = 150, w = 120, h = 150, xVel = 10, yVel = 10;
    public DanceEggS()
    {
        setBackground(c);
    }
    public void paint(Graphics g)
    {
        super.paint(g);
        setBackground(newColor());
        g.setColor(Color.WHITE);
        g.fillOval(x, y, w, h);
        if (x >= 385 || x <= 0)
        {
            xVel = -xVel;
        }
        x += xVel;
        if (y >= 150 || y <= 70)
        {
            yVel = -yVel;
        }
        y += yVel;
        
        g.drawString("sassy", 50 + (int)(Math.random() * 10), 50 + (int)(Math.random() * 10));
        g.drawString("extra crispy", 100 + (int)(Math.random() * 10), 200 + (int)(Math.random() * 10));
        g.drawString("wow", 200 + (int)(Math.random() * 10), 100 + (int)(Math.random() * 10));
        g.drawString("existential dread", 350 + (int)(Math.random() * 10), 175 + (int)(Math.random() * 10));
        Font font2 = new Font("Arial", Font.BOLD + Font.ITALIC, 80);
        g.setFont(font2);
        g.drawString("dance egg", 50, 350);
        try 
        {Thread.sleep(20);}
        catch (Exception e) {}
        repaint();
    }
    public Color newColor()
    {
        return new Color((int)(Math.random() * 255), (int)(Math.random() * 255), (int)(Math.random() * 255));
    }
   
}
