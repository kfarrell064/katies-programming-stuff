package DanceEggS;
import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout
public class WindowS
{
    public static void main(String[] args) 
    {
        JFrame theGui = new JFrame();
        theGui.setTitle("dance egg");
        theGui.setSize(500, 500);
        theGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        DanceEggS panel = new DanceEggS();
        Container pane = theGui.getContentPane();
        pane.add(panel);
        theGui.setVisible(true);
    }
}
