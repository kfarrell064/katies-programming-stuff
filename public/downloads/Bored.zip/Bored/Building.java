import javax.swing.*; //jframe and jpanel
import java.awt.*; 
public class Building
{
    int x;
    int w = (int)(Math.random() * 50) + 50;
    int h = (int)(Math.random() * 100) + 80;
    int y;
    int rando = (int)(Math.random() * 150);

    Color grayish = new Color(50 + rando, 50 + rando, 50 + rando);
    Color window = new Color(20 + rando, 20 + rando, 20 + rando);
    
    public Building(int xval)
    {   x = xval;
        y = 400 - h;
    }

    public void draw(Graphics g)
    {
        g.setColor(grayish);
        g.fillRect(x, y, w, h);
        if (rando % 3 == 0) 
        {
            int antennaW = (int)(w / 10);
            int antennaH = antennaW + 20;
            g.fillRect(x - (antennaW/2) + (w/2), y - antennaH, antennaW, antennaH);
        }
       /*
        if (rando % 6 == 0)
        {
            g.setColor(grayish);
            g.drawRect(x + rando, y + rando, 5, 5);
            g.setColor((int)(Math.random() * 255), (int)(Math.random() * 255), (int)(Math.random() * 255)
        }
        */
        for (int i = x + 10; i < (x + w) - 10; i += 10)
        {
            for (int n = y + 10; n < (y + h) - 10; n += 10)
            {
                g.setColor(window);
                g.fillRect(i, n, 3, 3);
            }
        }
    }

    public void update()
    {
        x -= 2;
    }

    public int getX()
    {
        return x;
    }

    public void setX(int newX)
    {
        x = newX;
    }
    
    public void nightColor()
    {
        grayish = new Color(10 + rando, 10 + rando, 50 + rando);
        window = new Color(255, 255, 150);
    }
}
