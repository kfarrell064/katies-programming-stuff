import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout
public class NightForest extends DayForest
{
    public NightForest()
    {
        sky = new Color(5, 105, 155);
        grass = new Color(35, 50, 70);
        sun = new Color(255, 255, 255);
        setBackground(sky);
        for (int i = 0; i < 10; i++)
        {
            trees[i].nightColor();
            clouds[i].nightColor();
        } 
    }  
}
