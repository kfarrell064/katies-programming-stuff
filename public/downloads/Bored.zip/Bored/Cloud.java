import javax.swing.*; //jframe and jpanel
import java.awt.*; 
public class Cloud
{
    int x;
    int w = (int)(Math.random() * 10) + 50;
    int h = (int)(Math.random() * 10) + 10;
    int y = (int)(Math.random() * 200) - 50;
   
    Color c = Color.WHITE;
    public Cloud(int xval)
    {   x = xval;
    }
    public void draw(Graphics g)
    {
        g.setColor(c);
        g.fillRect(x, y, w, h);
    }
    public void update()
    {
        x -= 1;
    }
    public int getX()
    {
        return x;
    }
    public void setX(int newX)
    {
         x = newX;
    }
    public void nightColor()
    {
        c = new Color(150, 200, 250);
    }
}
