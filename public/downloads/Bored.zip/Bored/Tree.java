import javax.swing.*; //jframe and jpanel
import java.awt.*; 
public class Tree
{
    int x;
    int w = (int)(Math.random() * 10) + 10;
    int h = (int)(Math.random() * 100) + 10;
    int y;
    int rando = (int)(Math.random() * 100);
    
    Color brown = new Color(100 + rando, 52 + rando, 52 + rando);
    Color leafy = new Color(100, 100 + (int)(Math.random() * 55), 100);
    
    public Tree(int xval)
    {   x = xval;
        y = 400 - h;
    }
    public void draw(Graphics g)
    {
        g.setColor(brown);
        g.fillRect(x, y, w, h);
        g.setColor(leafy);
        int leafW = w * 5;
        int leafH = leafW - 10;
        g.fillRect(x - (leafW/2) + (w/2), y - leafH, leafW, leafH);
    }
    public void update()
    {
        x -= 2;
    }
    public int getX()
    {
        return x;
    }
    public void setX(int newX)
    {
         x = newX;
    }
    public void nightColor()
    {
        brown = new Color(4 + rando, 2 + rando, 20 + rando);
        leafy = new Color(35, 50 + (int)(Math.random() * 10), 70);
    }
}
