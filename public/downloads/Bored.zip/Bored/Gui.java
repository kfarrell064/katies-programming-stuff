import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout

public class Gui
{
    public static void main(String[] args) 
    {   
        boolean quit = false;

        JFrame theGui = new JFrame();
        theGui.setTitle("Bored");
        theGui.setSize(500, 500);
        theGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container pane = theGui.getContentPane();
        pane.add(new NightForest());
        theGui.setVisible(true);
        /*
        while (!quit)
        {
            pane.removeAll();
            pane.add(new DayForest());
            theGui.setVisible(true);
            try {Thread.sleep(15000);}
            catch(Exception e) {}
            pane.removeAll();
            pane.add(new NightForest());
            theGui.setVisible(true);
            try {Thread.sleep(15000);}
            catch(Exception e) {}
        }
        */
    } 
   }

