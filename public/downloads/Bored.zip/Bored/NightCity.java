import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout
public class NightCity extends DayCity
{
    public NightCity()
    {
        sky = new Color(5, 105, 155);
        ground = new Color(50, 50, 80);
        setBackground(sky);
        for (int i = 0; i < 10; i++)
        {
            buildings[i].nightColor();
            clouds[i].nightColor();
        } 
    }  
}
