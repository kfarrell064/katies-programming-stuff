import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout
public class DayCity extends JPanel
{
    Color sky = new Color(200, 220, 235);
    Color ground = new Color(150, 150, 150);

    Cloud[] clouds = new Cloud[10];
    Building[] buildings = new Building[10];
    
    public DayCity()
    {
        setBackground(sky);
        for (int i = 0; i < 10; i++)
        {
            clouds[i] = new Cloud(i * 50);
            buildings[i] = new Building(i * 100);
        }
        
    }  

    public void paint(Graphics g)
    {
        super.paint(g);

        g.setColor(ground); //foreground
        g.fillRect(0, 400, 500, 80);
      
        
        for (int i = 0; i < 10; i++) //buildings and clouds
        {
            if (clouds[i].getX() < -50)
            {
                clouds[i].setX(550);
            }
            if (buildings[i].getX() < -85)
            {
                buildings[i].setX(555);
            }
            
            buildings[i].draw(g);
            clouds[i].draw(g);

            buildings[i].update();
            clouds[i].update();
        }

        repaint();
        try {Thread.sleep(50);}
        catch(Exception e) {}
    }
}