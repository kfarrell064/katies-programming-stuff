import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout
public class DayForest extends JPanel
{
    Color sky = new Color(105, 205, 255);
    Color grass = new Color(100, 150, 100);
    Color sun = new Color(255, 255, 150);
    
    Tree[] trees = new Tree[10];
    Cloud[] clouds = new Cloud[10];

    public DayForest()
    {
        setBackground(sky);
        for (int i = 0; i < 10; i++)
        {
            trees[i] = new Tree(i * 50); 
            clouds[i] = new Cloud(i * 50);
        }
        
    }  

    public void paint(Graphics g)
    {
        super.paint(g);

        g.setColor(grass); //foreground
        g.fillRect(0, 400, 500, 80);
        
        g.setColor(sun); //sun
        g.fillRect(30, 15, 50, 50);
        
        for (int i = 0; i < 10; i++) //trees and clouds
        {
            if (trees[i].getX() < -50)
            {
                trees[i].setX(550);
            }
            if (clouds[i].getX() < -50)
            {
                clouds[i].setX(550);
            }
            
            trees[i].draw(g);
            clouds[i].draw(g);
            
            trees[i].update();
            clouds[i].update();
        }

        repaint();
        try {Thread.sleep(50);}
        catch(Exception e) {}
    }
}
