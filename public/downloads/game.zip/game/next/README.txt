
alright get on your hoodies and snort your drugs cause this is a Mr. Robot CTF

the objective is to find a virtual "flag" -- a long, random string of characters hidden somewhere in this game

if you have the correct flag it should pass Admin Login

enter "chmod -R 755 ../next"
then ". ./.home.sh"

