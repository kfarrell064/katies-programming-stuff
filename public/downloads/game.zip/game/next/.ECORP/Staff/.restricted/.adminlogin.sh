#!/bin/bash
echo "Password: "
read pword
if [ $pword = mUVFybZk625NkotRbjtc ]
then
clear
echo '   __ _____  _______ _________  __  ______   _  __
  / // / _ |/ ___/ //_/ __/ _ \/  |/  / _ | / |/ /
 / _  / __ / /__/ ,< / _// , _/ /|_/ / __ |/    / 
/_//_/_/ |_\___/_/|_/___/_/|_/_/  /_/_/ |_/_/|_/  
                                                  '
echo ""
echo "You won!"
echo ""
cd ../../../..
else
echo "Invalid login"
fi
