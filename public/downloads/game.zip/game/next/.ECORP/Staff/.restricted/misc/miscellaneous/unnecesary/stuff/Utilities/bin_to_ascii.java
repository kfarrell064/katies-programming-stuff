import java.util.Scanner;
public class bin_to_ascii {    
    public static void main(String[] args) {    
        Scanner scan = new Scanner(System.in);
        System.out.println("Binary data: ");
        String s = scan.nextLine();
        String s2 = "";   
        char nextChar;
        for(int i = 0; i <= s.length()-8; i += 9) {
            nextChar = (char)Integer.parseInt(s.substring(i, i+8), 2);
            s2 += nextChar;
        }
        System.out.println("ASCII text:\n" + s2);
    }
}
