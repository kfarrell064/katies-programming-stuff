#!/bin/bash
echo "Password: "
read pword
if [ $pword = duckbaseballtree ]
then
echo "Login successful"
echo "Restricted files are now visible"
mv .restricted restricted
else
echo "Invalid login"
fi
