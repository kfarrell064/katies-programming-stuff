#!/bin/bash
clear
echo '    ____________               '
echo '   / ____/ ____/___  _________ '
echo '  / __/ / /   / __ \/ ___/ __ \'
echo ' / /___/ /___/ /_/ / /  / /_/ /'
echo '/_____/\____/\____/_/  / .___/ '
echo '                      /_/      '
echo 'Welcome, valued customer!'
echo '    *For company news, visit the News directory.'
echo '    *For account information, visit the Account directory.'
echo '    *For help, visit the Help directory.'
echo ''
cd .ECORP