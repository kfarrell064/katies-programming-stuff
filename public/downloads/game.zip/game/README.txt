instructions

* open "command prompt"

* ls

  type it in and hit ENTER. Pretty neato!
  short for "list"
  pretty much lists all the files and folders that are on your computer

  but wait!

  not every single file appears, because most of them are in folders, or "directories" like Desktop, Documents, etc
  if only there was a way to go inside of a directory

* cd

  short for "change directory"
  the equivalent of clicking on a folder
  to go into the Desktop folder from command prompt enter "cd Desktop"

  to see the files and folders once you're there, try "ls" again

  to go into another folder on your Desktop, try cd (folder name)
  to list all the files in (folder name)...you guessed it, ls

  this is cool but it seems like you can only move deeper into folders inside of folders inside of folders.
  how do you move back OUT of a folder?

  to move out of your current folder, or move "up" a directory, try "cd .."
  this will leave you in the folder that contains the folder you were just in

* cat

  directories don't have to just contain more directories
  they also have files (e.g., "README.txt")

  to print the text of a file, try cat (filename)


 * to begin

   navigate to the directory that this file is in (should be called "game") and look in the "next" directory



