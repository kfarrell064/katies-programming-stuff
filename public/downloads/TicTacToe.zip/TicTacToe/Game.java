import java.util.*; //misc utility classes
import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout
public class Game extends JPanel
{
    private String player = "O"; //start out with x
    private Square[][] board = new Square[3][3];
    Scanner scan = new Scanner(System.in);
    private boolean quit = false;

    /**
     * Clears the screen and initializes the board (sets the x and y coordinates of each Square).
     */
    public Game() 
    {
        System.out.println("\u000c");
        for (int r = 0; r < board.length; r++) 
        {
            for (int c = 0; c < board[r].length; c++)
            {
                board[r][c] = new Square((c * 100) + 20, (r * 100) + 90);
            }
        }
    }

    /**
     * Gets row and column coordinates from the current player and sets the symbol of that space to whatever the 
     * player variable is--IF the coordinates are within the board and not already taken. Checks to see if the game has
     * been won or tied and then switches the player.
     */
    public void play()
    {
        System.out.println("Player " + player + ": enter a row number 1 - 3");
        int rowNum = scan.nextInt() - 1; //subtract 1 to make it an array index
        System.out.println("Player " + player + ": enter a column number 1 - 3");
        int colNum = scan.nextInt() - 1;

        if (rowNum < board.length && colNum < board[0].length && rowNum > -1 && colNum > -1 
            && board[rowNum][colNum].getSym().equals(" "))
        {
            board[rowNum][colNum].setSym(player); //getSym() will equal " " when the space is empty
        }
        else {
            System.out.println("Invalid move! Try again");
            if (player.equals("X")) //switch players here so it will be switched back to original at the end
            {
                player = "O";
            }
            else
            {
                player = "X";
            }
        }
        if (won(board))
        {
            System.out.println("Player " + player + " wins!");
            scan.close();
            quit = true;
        }

        else if (full(board))
        {
            System.out.println("Tie!");
            scan.close();
            quit = true;
        }
        if (player.equals("X"))
        {
            player = "O";
        }
        else
        {
            player = "X";
        }
    }
    /**
     * Checks to see if the board has the same 3 symbols in a row, column, or diagonal (if it's not the default symbol)
     * @return true if the game has been won, otherwise false
     */
    public boolean won(Square[][] b)
    {
        //across
        for (int r = 0; r < b.length; r++) 
        {
            if (!(b[r][0].getSym().equals(" ")) && b[r][0].getSym().equals(b[r][1].getSym())
            && b[r][1].getSym().equals(b[r][2].getSym()))
            {
                return true;
            }
        }
        //down
        for (int c = 0; c < b[0].length; c++) 
        {
            if (!(b[0][c].getSym().equals(" ")) && b[0][c].getSym().equals(b[1][c].getSym()) 
            && b[1][c].getSym().equals(b[2][c].getSym()))
            {
                return true;
            }
        }
        //diagonals
        if (!(b[1][1].getSym().equals(" ")) && b[1][1].getSym().equals(b[0][2].getSym()) && 
        b[1][1].getSym().equals(b[2][0].getSym()))
        {
            return true;
        }
        if (!(b[1][1].getSym().equals(" ")) && b[1][1].getSym().equals(b[0][0].getSym()) && 
        b[1][1].getSym().equals(b[2][2].getSym()))
        {
            return true;
        }
        return false;
    }
    /**
     * Checks to see if all the spaces on the board are filled.
     * @return true if there are no empty spaces, false if there are
     */
    public boolean full(Square[][] b)
    {
        for (int r = 0; r < b.length; r++) 
        {
            for (int c = 0; c < b[r].length; c++)
            {
                if (b[r][c].getSym().equals(" "))
                {
                    return false;
                }
            }
        } 
        return true;
    }
    /**
     * Draws rectangles to divide the screen into a grid and then runs the draw() method for each of the Squares.
     */
    public void paint(Graphics g)
    {
        super.paintComponent(g);
        setBackground(Color.blue);
        g.setColor(Color.white);

        g.fillRect(110, 0, 5, 500);
        g.fillRect(205, 0, 5, 500);        
        g.fillRect(0, 100, 500, 5);
        g.fillRect(0, 200, 500, 5);

        for (int r = 0; r < board.length; r++)
        {
            for (int c = 0; c < board.length; c++)
            {
                board[r][c].draw(g);
            }
        }
        try {Thread.sleep(15);}
        catch(Exception e) {}
    }

    public boolean getQuit()
    {
        return quit;
    }
}