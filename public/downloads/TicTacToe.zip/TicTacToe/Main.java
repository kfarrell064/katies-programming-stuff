import javax.swing.*;
import java.awt.*; 

public class Main
{
    /**
     * Creates a new JFrame and Game. Continuously updates and repaints the game while getQuit() returns false.
     */
    public static void main(String[] args) 
    {
        JFrame theGui = new JFrame();
        theGui.setTitle("Tic Tac Toe");
        theGui.setSize(335, 335);
        theGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Game game = new Game();
        Container pane = theGui.getContentPane();
        pane.add(game);
        theGui.setVisible(true);
        while (game.getQuit() == false) 
        {
            try {Thread.sleep(60);}
            catch (Exception e) {}
            game.play();
            game.repaint();
        }
    }
}