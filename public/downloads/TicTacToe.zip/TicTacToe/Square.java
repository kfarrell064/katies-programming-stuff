import java.util.*;
import javax.swing.*; 
import java.awt.*;

public class Square
{
    private String symbol = " "; //default symbol is " "
    private int x, y;

    public Square(int newX, int newY) //allow the coordinates to be set when a Square is made
    {
        x = newX;
        y = newY;
    }

    public void setSym(String s) //allow the symbol to be changed from the Game class
    {
        symbol = s;
    }

    public String getSym() //allow the symbol to be checked from the Game class
    {
        return symbol;
    }

    public void draw(Graphics g) //draw the symbol at the x and y coordinates
    {
        Font font1 = new Font("Arial", Font.PLAIN, 100);
        g.setFont(font1);
        g.drawString(symbol, x, y);
    }
}
