import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout
public class Gui
{
    /**
     * Goes through standard process of creating a JFrame and adding a JPane.
     */
    public Gui() 
    {
        JFrame theGui = new JFrame();
        theGui.setTitle("Binary Clock");
        theGui.setSize(375, 215);
        theGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ClockPanel panel = new ClockPanel();
        Container pane = theGui.getContentPane();
        pane.add(panel);
        theGui.setVisible(true);
    }
}
