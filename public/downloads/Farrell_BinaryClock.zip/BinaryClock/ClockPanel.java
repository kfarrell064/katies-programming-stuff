import java.util.*; //misc utility classes
import javax.swing.*; //jframe and jpanel
import java.awt.*; //color and container and gridLayout
public class ClockPanel extends JPanel
{
    public ClockPanel()
    {
        setBackground(Color.black);
    }

    /**
     * Compares an integer x with each number in the places array (powers of 2 up to 32). Once it reaches
     * the first place that is less than x, it replaces that spot in the ans array (of the same length) with 
     * a 1.Continues the process with x minus the value that we've already represented.
     * @return an array of 1s and 0s
     */
    public int[] binary(int x)
    {
        int[] ans = {0, 0, 0, 0, 0, 0}; 
        int[] places = {32, 16, 8, 4, 2, 1};

        for (int i = 0; i < 6; i++)
        {
            if (x % places[i] != x) //if the place is smaller than x
            {
                ans[i] = 1; 
                x -= places[i]; 
            }
        }

        return ans;
    }

    /**
     * Uses JPanel's definition of paintComponent(g), creates a new GregorianCalender object called cal,
     * and creates new int[] arrays containing the current hour, minute, and second as arrays of binary
     * digits (using binary(int x)). Loops through every index for all 3 arrays, and if it finds a 1, draws a 
     * filled circle of width and height 50 at the coordinates i * 50, y where 'i' is loop counter and 'y' is different
     * for each array (making 3 different rows). Otherwise, draws an empty circle. i * 50 makes them each 50 spaces apart on 
     * the x axis (prevents overlap). The repaint() updates it perpetually. 
     */
    public void paint(Graphics g) 
    {
        super.paintComponent(g);

        GregorianCalendar cal = new GregorianCalendar();
        
        int[] binHours = binary(cal.get(Calendar.HOUR_OF_DAY));
        int[] binMins = binary(cal.get(Calendar.MINUTE));
        int[] binSecs = binary(cal.get(Calendar.SECOND));

        g.setColor(Color.cyan);

        for (int i = 0; i < 6; i++)
        {
            if (binHours[i] == 1)
            {
                g.fillOval(i * 50, 10, 50, 50);
            }
            else {
                g.drawOval(i * 50, 10, 50, 50); 
            }
            if (binMins[i] == 1)
            {
                g.fillOval(i * 50, 60, 50, 50);
            }
            else {
                g.drawOval(i * 50, 60, 50, 50); 
            }
            if (binSecs[i] == 1)
            {
                g.fillOval(i * 50, 110, 50, 50);
            }
            else {
                g.drawOval(i * 50, 110, 50, 50); 
            }
        }
        
        //draw labels
        String space = " \t \t \t \t ";
        g.drawString("hours", 320, 35);
        g.drawString("minutes", 320, 85);
        g.drawString("seconds", 320, 135);
        g.drawString("32" + space + "16" + space + "08" + space + "04" + space + "02" + space + "01", 13, 180);
       
        //pause before looping through again
        try {Thread.sleep(60);}
        catch(Exception e) {}
        repaint();
    }
}

