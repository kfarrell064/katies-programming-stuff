INSTRUCTIONS FOR USING BLACKJACK:

This game has to be run from the console because I'm lazy. To do this, open Terminal and navigate to whatever directory this is saved in. Then type 'java jackblack/Blackjack'.

You can also double-click any of the .java files in Finder to look at the code in TextEdit.