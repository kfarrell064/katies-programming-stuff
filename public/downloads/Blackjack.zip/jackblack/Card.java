package jackblack;

public class Card {
	private int value;
	private String suit;

	public int getValue() {
		return value;
	}
	public String getSuit() {
		return suit;
	}
	
	public Card(int value, String suit) {
		this.value = value;
		this.suit = suit;
	}
	public String toString() {
		if (value == 11) {
			return "the jack of " + suit;
		}
		else if (value == 12) {
			return "the queen of " + suit;
		}
		else if (value == 13) {
			return "the king of " + suit;
		}
		else if (value == 1) {
			return "the ace of " + suit;
		}
		return "the " + value + " of " + suit;
	}
}
