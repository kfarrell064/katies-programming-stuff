package jackblack;

import java.util.Random;

public class Deck {
	Card[] cards = new Card[52];
	public Deck() {
		for (int x = 0; x < 52; x++) {
			if (x < 13) {
				//hearts
				cards[x] = new Card((x + 1), "hearts");
			}
			else if (x < 26) {
				//diamonds
				cards[x] = new Card((x - 12), "diamonds");
			}
			else if (x < 39) {
				//clubs
				cards[x] = new Card((x - 25), "clubs");
			}
			else {
				//spades
				cards[x] = new Card((x - 38), "spades");
			}	
		}
	}
	public void printDeck() {
		for (int y = 0; y < 52; y++) {
			System.out.println(cards[y]);
		}
	}
	public void shuffle() {
		Random rand = new Random(); 
		for (int z = 0; z < 52; z++) {
			int num = rand.nextInt(52);
			Card randomCard = cards[num];
			cards[num] = cards[z];
			cards[z] = randomCard; //swapping each card with a random one in the deck
		}
	}
	
	public Card getCard(int cardNum) {
		return cards[cardNum];
	}
	
	public int getVal(int cardNum) {
		return cards[cardNum].getValue();
	}
	
}
