package jackblack;

import java.util.ArrayList;
import java.util.Scanner;

public class Blackjack {
	static int round = 0;
	public static void main(String[] args) {
		Deck gamedeck = new Deck();
		int playerTotal = 0;
		int dealerTotal = 0;
		//		gamedeck.printDeck();
		gamedeck.shuffle();
		ArrayList<Integer> hand1 = new ArrayList<Integer>();
		ArrayList<Integer> hand2 = new ArrayList<Integer>();
		System.out.println("PLAYER TURN");
		playerTotal += playerHit(gamedeck, hand1);
		System.out.println("DEALER TURN");
		dealerTotal += playerHit(gamedeck, hand2);
		if ((21 - playerTotal) < (21 - dealerTotal)) {
			System.out.println("player wins! The dealer had " + dealerTotal);
		}
		else {
			System.out.println("player loses! The dealer had " + dealerTotal);
		}
	}

	public static int playerHit(Deck deck, ArrayList<Integer> hand) {
		Scanner scan = new Scanner(System.in);
		int total = 0;
		boolean hit = true;
		boolean lost = false;
		//initial card
		total += addCard(deck, hand);
		round++;

		while (hit == true) {
			total += addCard(deck, hand);

			System.out.println(" ");
			System.out.println("hand: " + hand);
			System.out.println("total = " + total);
			System.out.println(" ");

			if (total < 22) {
				System.out.println("hit (y/n)?");
				String cont = scan.next();

				if(!cont.equals("y")) {
					hit = false;
				}
			}
			else {
				if (hand.contains(11)) {
					hand.remove(hand.indexOf(11));
					hand.add(1);
					total -= 10;
					System.out.println(" ");
					System.out.println("ace is converted to 1 when it is beneficial to the player");
					System.out.println("hand: " + hand);
					System.out.println("total = " + total);
					System.out.println(" ");
					System.out.println("hit (y/n)?");
					String cont = scan.next();

					if(!cont.equals("y")) {
						hit = false;
					}
					
				}
				else {
					hit = false;
					lost = true;
				}
			}
			round++;
		}
		if (lost == true) {
			System.out.println("over 21!");
			System.out.println(" ");
			total = 0;
			return total;
		}
		return total;
	}
	
	public static int addCard(Deck deck, ArrayList<Integer> hand) {
		int total = 0;
		System.out.println(deck.getCard(round));
		if (deck.getVal(round) > 10) {
			hand.add(10);
			total += 10;
		}
		else if (deck.getVal(round) == 1) { //for aces
			if (total < 11) {
				hand.add(11);
				total += 11;
			}
			else {
				hand.add(1);
				total += 1;
			}
			
		}
		else {
			hand.add(deck.getVal(round));
			total += deck.getVal(round);
		}
		return total;
	}


}
