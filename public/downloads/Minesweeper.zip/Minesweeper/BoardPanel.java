import javax.swing.*; 
import java.awt.*;
import java.awt.event.*;

public class BoardPanel extends JPanel implements MouseListener, KeyListener
{
    /*------SETUP (variables, constructor)-----*/
    final int LEN = 9;
    Square[][] board = new Square[LEN][LEN];
    final int NUM_MINES = 10;    
    static boolean newGame = false;
    static boolean gameOver = false;
    boolean flagMode = false;
    boolean win = false; 
    long startTime;
    int currTime;

    public BoardPanel()
    {
        startTime = System.currentTimeMillis();
        addMouseListener(this);
        addKeyListener(this);
        //initialize board
        for (int r = 0; r < board.length; r++)
        {
            for (int c = 0; c < board[r].length; c++)
            {
                board[r][c] = new Square();
            }
        }
        //set mines
        for (int i = 0; i < NUM_MINES; i++)
        {
            int randX = (int) (Math.random() * LEN), randY = (int) (Math.random() * LEN);
            while (board[randX][randY].getMine())
            {
                randX = (int) (Math.random() * LEN);
                randY = (int) (Math.random() * LEN);
            }
            board[randX][randY].setMine(true);
        }
        //set numbers
        for (int r = 0; r < board.length; r++)
        {
            for (int c = 0; c < board[r].length; c++)
            {
                int mineNum = 0; 
                //for each square on the board, check the adjacent squares for mines
                for (int adjRow = r - 1; adjRow <= r + 1; adjRow++)
                {
                    for (int  adjCol = c - 1; adjCol <= c + 1; adjCol++)
                    {
                        if (adjRow < board.length && adjRow >= 0 
                        && adjCol < board[r].length && adjCol >= 0)//if on board 
                        {
                            if (board[adjRow][adjCol].getMine())
                                mineNum++;
                        }
                    }
                }
                board[r][c].setNum(mineNum);
            }
        }
    }

    /*------INPUT STUFF (keylistener, mouselistener, clickall)-----*/
    //for keylistener
    @Override
    public void addNotify() {
        super.addNotify();
        requestFocus();
    }

    @Override
    public void mousePressed(MouseEvent e)
    {
        int mouseRow = (int) (e.getX()/50); //squares are 50 tall/wide
        int mouseCol = (int) (e.getY()/50);
        if (!flagMode && !gameOver) //no clicking or flagging when game is over
            clickAll(mouseRow, mouseCol);
        else if (!gameOver)
            board[mouseRow][mouseCol].flag();
    }

    @Override
    public void mouseClicked(MouseEvent e){}

    @Override
    public void mouseEntered(MouseEvent e){}

    @Override
    public void mouseExited(MouseEvent e){}

    @Override
    public void mouseReleased(MouseEvent e){}

    @Override
    public void keyPressed(KeyEvent e)
    {
        if (e.getKeyChar() == 'f' && !gameOver) //no flagging when game is over
        {
            if (!flagMode)
                flagMode = true;
            else
                flagMode = false;
        }
        else if (e.getKeyChar() == 'n')
        {
            newGame = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e){}

    @Override
    public void keyTyped(KeyEvent e){}

    public void clickAll(int startRow, int startCol)
    {
        try {
            //click current, then if it has value 0 click all adjacent that don't  have mines,
            //then if any of the adjacent have value 0 click all adjacent that don't have mines, etc
            board[startRow][startCol].click(); 
            for (int adjRow = startRow - 1; adjRow <= startRow + 1; adjRow++)
            {
                for (int  adjCol = startCol - 1; adjCol <= startCol + 1; adjCol++)
                {
                    if (adjRow < board.length && adjRow >= 0 
                    && adjCol < board[startRow].length && adjCol >= 0)//if on board 
                    {
                        if (board[startRow][startCol].getNum() == 0 
                        && !board[adjRow][adjCol].getClick() && !board[adjRow][adjCol].getMine())
                            clickAll(adjRow, adjCol);
                    }
                }
            }
        }
        catch (ArrayIndexOutOfBoundsException a){} //off-board clicks
    }
    
    /*------GAMEPLAY (paint, main)-----*/
    @Override
    public void paint(Graphics g)
    {
        gameOver = false;
        win = true;
        super.paint(g);
        setBackground(Color.black);
        g.setColor(Color.green);

        for (int r = 0; r < board.length; r++)
        {
            for (int c = 0; c < board[r].length; c++)
            {
                //draw different kinds of squares, check for loss
                if (board[r][c].getClick() && board[r][c].getMine()) 
                {
                    gameOver = true;
                    g.setColor(Color.red);
                    g.drawString("(GAME OVER)", 200, 485);
                    g.setColor(Color.red);
                    g.fillRect(r * 50, c * 50, 50, 50); 
                    g.setColor(Color.green);
                }
                else if (!board[r][c].getClick() && board[r][c].getFlag())
                {
                    g.drawRect(r * 50, c * 50, 50, 50);
                    g.fillRect((r * 50) + 12, (c * 50) + 12, 25, 25);
                }
                else if (!board[r][c].getClick())
                {
                    g.drawRect(r * 50, c * 50, 50, 50);
                    if (flagMode)
                        g.drawString(".", (r * 50) + 25, (c * 50) + 25);
                }
                else {
                    g.fillRect(r * 50, c * 50, 50, 50); 
                    g.setColor(Color.black);
                    g.drawString("" + board[r][c].getNum(), (r * 50) + 20, (c * 50) + 30);
                    g.setColor(Color.green);
                }
                //check for win: if it's unclicked and doesn't have a mine it's false
                if (!board[r][c].getClick() && !board[r][c].getMine())
                    win = false;
            }
        }
        if (win && !gameOver) //if the game isn't lost and all non-mine squares clicked 
        {
            g.setColor(Color.red);
            g.drawString("(WIN!)", 200, 485);
            g.setColor(Color.green);
            gameOver = true;
        }
        if (!gameOver) //stop updating time after game is over
            currTime = Math.abs((int)((startTime - System.currentTimeMillis())/1000));
        g.drawString("TIME: " + currTime, 20, 485);
        g.drawString("Click to open a square", 20, 500);
        g.drawString("Press F to toggle flagging mode; click to flag/unflag", 20, 515);
        g.drawString("Press N for new game", 20, 530);
    }

    public static void main(String[] args) {
        JFrame theGui = new JFrame();
        theGui.setTitle("Minesweeper");
        theGui.setSize(452, 600);
        theGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container pane = theGui.getContentPane();
        pane.add(new BoardPanel());
        theGui.setVisible(true);
        while (!newGame)
        {
            theGui.repaint();
        }
        if (newGame)
        {
            newGame = false;
            theGui.dispose();
            main(new String[0]);
        }
    }
}
