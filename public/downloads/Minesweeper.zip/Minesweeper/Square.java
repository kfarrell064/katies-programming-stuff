public class Square
{
    private boolean mine = false;
    private int num = 0;
    private boolean click = false;
    private boolean flag = false;
    
    public void setMine(boolean b)
    {
        mine = b;
    }
    public void setNum(int i)
    {
        num = i;
    }
    public void click()
    {
        click = true;
    }
    public void flag()
    {
        if (!flag)
            flag = true;
        else
            flag = false;
    }
    public boolean getMine()
    {
        return mine;
    }
    public int getNum()
    {
        return num;
    }
    public boolean getClick()
    {
        return click;
    }
    public boolean getFlag()
    {
        return flag;
    }
}
